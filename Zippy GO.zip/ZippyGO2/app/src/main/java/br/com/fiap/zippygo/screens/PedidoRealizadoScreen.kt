package br.com.fiap.zippygo.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import br.com.fiap.zippygo.R
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun PedidoRealizadoScreen(navController: NavController) {
    Box(modifier = Modifier
        .fillMaxSize()
        .background(colorResource(id = R.color.black_app)
        )
        .padding(top = 32.dp)
        ) {
        IconButton(
            onClick = {navController.navigate("pagamento")},
            modifier = Modifier
                .size(60.dp)
                .background(
                    color = colorResource(R.color.back_button),
                    shape = RoundedCornerShape(8.dp))
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = colorResource(id = R.color.green_button),
                modifier = Modifier.size(32.dp)
            )
        }
        Column(
            modifier = Modifier.padding(32.dp)
        ) {
            Spacer(Modifier.height(50.dp))
            Image(
                painter = painterResource(id = R.drawable.zippy_go_logo),
                contentDescription = "Zippy GO logo",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(height = 35.dp),
                alignment = Alignment.TopStart
            )
            Text(
                text = "Seu pedido foi realizado com sucesso.",
                modifier = Modifier.fillMaxWidth(),
                color = colorResource(id = R.color.white_letra2),
                fontSize = 20.sp
            )
            Spacer(Modifier.height(40.dp))
            Text(
                text = "Acompanhar entrega:",
                modifier = Modifier.fillMaxWidth(),
                color = colorResource(id = R.color.green_button),
                fontSize = 17.sp
            )
            Spacer(Modifier.height(36.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(colorResource(id = R.color.green_button))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Pedido lido",
                    color = colorResource(id = R.color.white_letra2),
                )
            }
            Spacer(Modifier.height(5.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(colorResource(id = R.color.green_button))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "O restaurante está preparando seu pedido",
                    color = colorResource(id = R.color.white_letra2),
                )
            }
            Spacer(Modifier.height(5.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(colorResource(id = R.color.black_textfield))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Sua entrega está em rota",
                    color = colorResource(id = R.color.black_textfield),
                )
            }
            Spacer(Modifier.height(5.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(colorResource(id = R.color.black_textfield))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Chegouu !",
                    color = colorResource(id = R.color.black_textfield),
                    fontSize = 25.sp
                )
            }
            Spacer(modifier = Modifier.height(36.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(
                    text = "Rastreio",
                    color = colorResource(id = R.color.green_button),
                    fontSize = 20.sp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "AO VIVO",
                    color = colorResource(id = R.color.white_letra2),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(colorResource(id = R.color.red_aovivo))
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Image(
                painter = painterResource(id = R.drawable.googlemaps),
                contentDescription = "Google Maps do Trajeto do seu pedido",
                modifier = Modifier
                    .height(230.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
        }
    }
}